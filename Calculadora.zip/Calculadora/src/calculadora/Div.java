
package calculadora;
import java.util.Scanner;


public class Div {
    public void add(){
        Scanner input = new Scanner(System.in);
        
    
        long n1;
        long n2;
        long res;
        System.out.println("Digite o primeiro número: ");
        n1 = input.nextLong();
        System.out.println("Digite o Segundo número :");
        n2 = input.nextLong();
        res = n1/n2;
        System.out.println("R E S U L T A D O : "+res);

        }
}
