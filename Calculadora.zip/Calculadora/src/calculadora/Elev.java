
package calculadora;
import java.util.Scanner;


public class Elev {
    public void add(){
        Scanner input = new Scanner(System.in);
        
    
        long base;
        long potencia;
        long res;
        System.out.println("Digite a base: ");
        base = input.nextLong();
        System.out.println("Digite a potencia :");
        potencia = input.nextLong();
        res = (long) Math.pow(base,potencia);
       
        System.out.println("R E S U L T A D O : "+res);
        }
        }


